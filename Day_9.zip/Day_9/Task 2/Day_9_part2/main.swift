//
//  main.swift
//  Day_9_part2
//
//  Created by Sreejith Thrivikraman on 2018-02-08.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//



// example to denote the usage of subscript for a structure.

import Foundation

struct Matrix
{
    let rows: Int, columns: Int
    var grid: [Double]
    
    init?(rows: Int, columns: Int)
    {
        self.rows = rows
        self.columns = columns
        grid = Array(repeating: 0.0,count: rows * columns)   // array - default setting concept.
        
        if grid.isEmpty
        {
            return nil
        }
    }
    
    func indexIsValid(row: Int,column: Int) -> Bool
    {
       return row >= 0 && row < rows && column >= 0 && column  < columns
    }
    
    subscript(row: Int, column:Int) -> Double
    {
        get {
            assert(indexIsValid(row: row, column: column),"index out of range")
            // assert is the keyword to check the condition if it is true or not.
           
            return grid[(row * columns) + column]
            
            }
        
        set {
            assert(indexIsValid(row: row, column: column),"Index out of range")
            grid[(row * columns) + column] = newValue
            }
    }
}

var matrix = Matrix(rows: 2, columns: 3)

if matrix == nil
{
    print("Matrix not created")
}

print(matrix?.grid)
matrix![0,1] = 1.5
matrix![1,0] = 3.2

print(matrix!.grid)









