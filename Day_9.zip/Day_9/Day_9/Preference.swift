//
//  Preference.swift
//  Day_9
//
//  Created by Sreejith Thrivikraman on 2018-02-08.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import Foundation

class Preference :Vehicle
{
    var prefer = false
    var description: String {
        var output = "Do you prefer\(noOfWheels) wheel vehicle from \(name) ?"
        output += prefer ? "✓" : "✕"
        return output
        
    }
}
