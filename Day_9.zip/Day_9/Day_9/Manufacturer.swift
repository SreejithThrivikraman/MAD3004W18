//
//  Manufacturer.swift
//  Day_9
//
//  Created by Sreejith Thrivikraman on 2018-02-08.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import Foundation
class  Manufacturer
{
    var name: String
    
    // Designated initiaizer
    init(name:String)
    {
        self.name = name
    }
    
    convenience init()                  // udsage of the convinent initializer.
    {
        self.init(name:"[Unknown]")
    }
    
    
}
