//
//  Cartitem.swift
//  Day_9
//
//  Created by Sreejith Thrivikraman on 2018-02-08.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import Foundation

class CartItem: Product {
    let quantity: Int
    
    
    init?(name: String, quantity: Int) {
        if quantity < 1 {
            //return nil
            self.quantity = 1
        }
        else{
            self.quantity = quantity
        }
        super.init(name: name)
    }
    
  
    
}



