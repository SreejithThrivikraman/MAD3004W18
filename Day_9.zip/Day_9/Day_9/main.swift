//
//  main.swift
//  Day_9
//
//  Created by Sreejith Thrivikraman on 2018-02-08.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import Foundation

// creating object for the class to check failing initializer.
var object_license = main_1()
object_license.creation()



//no parameter
let noObject  = Vehicle()

//one parameter
let alienVehicle = Vehicle(name: "BMW");

//both parameters
let bicycle = Vehicle(name: "BMW", noOfWheels: 2);

let preference = Preference()
//let preference = Preference(name: "BMW", noOfWheels: 2)
print(preference.description)
// concept of failable initiliser.

// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<
let laptop = Product(name: "Laptop")

if let machine = laptop {
    print("Product name is \(machine.name)")
}

let anonymousMachine = Product(name: "")

if anonymousMachine == nil {
    print("The anonymous machine could not be initialized")
}

if let oneProjector = CartItem(name: "Projector", quantity: 0){
    print("Cart contains \(oneProjector.quantity) \(oneProjector.name)")
}else {
    print("Unable to initialize cart item.")
}






