//
//  Person.swift
//  Day_9
//
//  Created by Sreejith Thrivikraman on 2018-02-08.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import Foundation
class Person
    
{
    var first_name: String
    var last_name: String
    var address: String
    
    init(F_name:String,L_name:String,addr:String)
    {
        
        self.first_name = F_name
        self.last_name = L_name
        self.address = addr
        
    }
}
