//
//  main_1.swift
//  Day_9
//
//  Created by Sreejith Thrivikraman on 2018-02-08.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import Foundation




class main_1
{
    var create = License(name1: "Sreejith", name2: "Thrivikraman", arg_addr: "36 cedar drive", arg_age: 12, arg_lic_no: "KL234-67")
    
    func creation ()
    {
        if(create == nil)
        {
            print("Object creation failed")
        }
        else
        {
            print("Object creation successful")
        }
    }
}






