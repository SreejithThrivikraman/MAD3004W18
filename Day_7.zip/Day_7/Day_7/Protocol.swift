//
//  Protocol.swift
//  Day_7
//
//  Created by Sreejith Thrivikraman on 2018-02-06.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import Foundation

protocol IDisplay {
    func display()
}

protocol  IDisplayValue {
    var n1 : Int { get set}
    func displayValue()
}

protocol ICalculate {
    var n1: Int { get set}
    var n2: Int {get set}
    
    init(n1: Int,n2: Int)        // this initialiser must be defined in the class implimenting the class.
}

