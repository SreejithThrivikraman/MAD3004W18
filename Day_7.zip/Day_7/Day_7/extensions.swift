//
//  extensions.swift
//  Day_7
//
//  Created by Sreejith Thrivikraman on 2018-02-06.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import Foundation

// extension is used to give more meaning to the type.

extension Double
    
{
    var km: Double { return self * 1_000.0 }
    var m: Double  { return self }
    var cm: Double { return self / 100.0 }
    var mm: Double { return self / 1_000.0 }
    var ft: Double { return self / 3.28084 }
}


extension String
    
{
    var length: Int {
                        get {
                            return self.count
                            }
                    }
    var vowels: [String] {
                            get {
                                return ["a","e","i","o","u"]
                                }
                        }
    var consonents: [String] {
        get {
            return ["b","c","d","f","g","h","j","k","l","m","n","p","q","r","t","s","v","w","x","y","z"]
        }
    }
}


extension Int {
    var isPrime: Bool {
        guard self > 1 else {
            return false
        }
        
        for i in 2..<self {
            if self % i == 0 {
                
                return false
            }
        }
        
        return true
    }
    
}
