//
//  main.swift
//  Day_7
//
//  Created by Sreejith Thrivikraman on 2018-02-06.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import Foundation

var obj1 = TestA()
obj1.n1 = 20
obj1.display()

var obj2 : IDisplay = TestA()
obj2.display()
obj2 = obj1 as TestA        // type casting to object of class TestA
obj2.display()

var obj3 = TestB()
obj3.n2 = 23
obj3.display()
obj3.displayValue()


var obj4 = Arithmetic(n1:30,n2:20)
obj4.calculate()

var obj5 = Operator(n1:100,n2:20,oper: "+")
obj5.calculate()


// using extensions for double. Refer extensions.swift
var l1 : Double = 1000
print("conversion to mm>>>>>>",l1.mm)

var cm : Double = 2000
print("conversion from cm >>>",cm.cm)

// using extensions for String variables.

var S : String = "Locally"
print(">>>>>>>>>>>length = ",S.length)
print(">>>>>>>>>>>vowels = ",S.vowels)
print(">>>>>>>>>>>consonents = ",S.consonents)


var integer : Int = 9
var flag : Bool

flag = integer.isPrime
if(flag == true)















