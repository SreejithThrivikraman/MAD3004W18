//
//  Arithmetic.swift
//  Day_7
//
//  Created by Sreejith Thrivikraman on 2018-02-06.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import Foundation

class Arithmetic: ICalculate
{
    var n1: Int
    var n2: Int
    
    required init( n1: Int, n2: Int)
    {
        self.n1 = n1
        self.n2 = n2
    }
    
    func calculate() {
        let result = self.n1 + self.n2
        print("Result is = ",result)
    }
}
