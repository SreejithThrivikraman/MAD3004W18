//
//  TestA.swift
//  Day_7
//
//  Created by Sreejith Thrivikraman on 2018-02-06.
//  Copyright © 2018 Sreejith Thrivikraman. All rights reserved.
//

import Foundation

class TestA: IDisplay      //
{
    var n1: Int = 0
   
    
    func displayValue()   // function implimented from the protocol.
    {
        print("value of n1 :",self.n1)
    }
    
    func display() {
        print("value of n1 is ",n1)
    }
}
